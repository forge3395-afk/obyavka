ОБЪЯВКА — Android-проект
=======================

Что внутри
- app/src/main/assets/obyavka.html — вся игра (работает без интернета).
- MainActivity.java — открывает игру в WebView на весь экран.
- Логины и прогресс хранятся в самом приложении (localStorage WebView).

Как собрать APK (Android Studio, 5 минут)
1. Установи Android Studio (https://developer.android.com/studio). При первом запуске
   согласись на установку Android SDK (Platform 34).
2. File → Open → выбери папку ObyavkaAndroid.
3. Дождись окончания Gradle Sync (внизу появится прогресс).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Готово: кнопка «locate» в уведомлении покажет файл
   app/build/outputs/apk/debug/app-debug.apk

Установка на телефон
- Скинь app-debug.apk на телефон, открой файл и разреши установку из этого источника.
- Или подключи телефон по USB с включённой отладкой и нажми Run ▶.

Обновление игры
- Замени app/src/main/assets/obyavka.html новой версией и пересобери APK.
- Прогресс сохраняется при обновлении (пока не удалено приложение).

Публикация в Google Play (по желанию)
- Build → Generate Signed Bundle / APK → Android App Bundle.
- Нужен аккаунт разработчика Google Play (разовый взнос 25 $).
- В манифесте уже есть applicationId com.obyavka.game — при публикации его можно поменять.

Если сборка падает
- Открой File → Project Structure → Project и убедись, что Android Gradle Plugin 8.5.2 и Gradle 8.7.
- Если Gradle не скачивается — проверь интернет и нажми File → Sync Project with Gradle Files.
